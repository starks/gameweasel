/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2008, 2009, 2010 Brian Marshall, Michael Ryan, Andrianto Effendy
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var gamefox_lib =
{
  domain: 'http://www.gamefaqs.com',
  path: '/boards/',

  getPref: function(pref)
  {
    return prefs[pref];
  },

  setPref: function(pref, value)
  {
    chrome.extension.sendRequest({'set': [pref, value]});
  },

  /*
     Facts, based on Firefox 2:
     - Host name normally can be fetched from document.location.host,
       document.location.hostname, and document.domain properties, as string.
     - If the page uses system protocol (e.g. about:<something>), then it might
       not have document.location.host and document.location.hostname
       properties, but it still has document.domain property whose content is
       null.
     - chrome: pages throw an exception when accessing document.domain.
     - For normal page, if it is not loaded successfully and therefore Firefox
       displays its custom warning page (e.g. Server not found), then its
       document.location.host and document.location.hostname properties remain
       pointing to the original URI, but its document.domain property content
       will be null.
   */

  onBoards: function(doc)
  {
    return /^\/boards(\/|$|\?)/.test(doc.location.pathname);
  },

  onPage: function(doc, page)
  {
    if (doc.gamefox.pageType)
      return doc.gamefox.pageType.indexOf(page) != -1;

    // pageType is an array because of overlapping pages, e.g. message detail and messages
    switch (page)
    {
      case 'index':
        var div = doc.getElementById('side_col');
        if (div)
        {
          var bi = doc.evaluate('./div[@class="pod"]/div[@class="head"]/h2', div,
              null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (bi && bi.textContent == 'Board Information')
          {
            doc.gamefox.pageType = ['index'];
            return true;
          }
        }
        return false;

      case 'topics':
        var div = doc.getElementById('board_wrap');
        if (div)
        {
          if (gamefox_lib.onPage(doc, 'tracked'))
          {
            doc.gamefox.pageType = ['topics', 'tracked'];
            return true;
          }
          var col = doc.evaluate('./div[@class="body"]/table[@class="board topics"]/colgroup/col[@class="status"]',
              div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (col)
          {
            doc.gamefox.pageType = ['topics'];
            return true;
          }
          // TODO: iterate over all <p> nodes (fails case when deleting only topic on board)
          var notopics = doc.evaluate('./p', div, null,
              XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (notopics && notopics.textContent.indexOf('No topics are available') != -1)
          {
            doc.gamefox.pageType = ['topics'];
            return true;
          }
        }
        return false;

      case 'messages':
        var div = doc.getElementById('board_wrap');
        if (div)
        {
          var table = doc.evaluate('./div[@class="body"]/table[@class="board message"]',
              div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (table && !gamefox_lib.onPage(doc, 'usernote'))
          {
            var boards = doc.evaluate('./div[@class="body"]', div, null,
                XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            if (boards.snapshotLength > 1)
              doc.gamefox.pageType = ['messages', 'detail'];
            else
            {
              // TODO: maybe check for user profile links instead
              var user = doc.evaluate('./div[@class="board_nav"]/div[@class="body"]/div[@class="user"]',
                  div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
              if (user && user.textContent.indexOf('Topic Archived') != -1)
                doc.gamefox.pageType = ['messages', 'archive'];
              else
                doc.gamefox.pageType = ['messages'];
            }
            return true;
          }
        }
        return false;

      case 'boardlist':
        var div = doc.getElementById('board_wrap');
        if (div)
        {
          var table = doc.evaluate('./div[@class="body"]/table[@class="board"]',
              div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (table && !gamefox_lib.onPage(doc, 'index'))
          {
            doc.gamefox.pageType = ['boardlist'];
            return true;
          }
        }
        return false;

      default:
        return doc.location.pathname.indexOf('/boards/' + page + '.php') == 0;
    }
  },

  setTitle: function(doc, title, prefix, page)
  {
    if (!gamefox_lib.getPref('elements.titlechange'))
    {
      // fix GameFAQs' double encoding of topic title
      doc.title = gamefox_utils.specialCharsDecode(doc.title);
      return;
    }
    if (!gamefox_lib.getPref('elements.titleprefix')) prefix = null;

    doc.title = 'GameFAQs'
      + (prefix == null ? '' : ':' + prefix)
      + (page == null ? '' : ':' + page)
      + ': ' + title;

    if (doc.defaultView.parent != doc.defaultView.self) // we're in a frame
      doc.defaultView.parent.document.title = doc.title;
  },

  open: function(tagID, openType)
  {
    var IDs = tagID.split(',');
    var tagURI = gamefox_lib.domain + gamefox_lib.path;

    tagURI += (IDs[1] ? 'genmessage.php' : 'gentopic.php')
              + '?board=' + IDs[0] + (IDs[1] ? '&topic=' + IDs[1]
              + (IDs[2] && parseInt(IDs[2]) ? '&page=' + IDs[2]
              + (IDs[3] ? IDs[3] : '') : '') : '');

    this.openPage(tagURI, openType);
  },

  openPage: function(url, openType)
  {
    switch (openType)
    {
      case 0: // new tab
        chrome.extension.sendRequest({'tab': [url, false]});
      break;
      case 1: // new focused tab
        chrome.extension.sendRequest({'tab': [url, true]});
      break;
      case 2: // focused tab
        window.location.href = url;
      break;
      case 3: // new window
        window.open(url);
      break;
    }
  },

  isLoggedIn: function()
  {
    return document.cookie.search('MDAAuth') != -1;
  }
};
