function default_prefs()
{
	prefs = {
		'elements.quickpost.form' : true,
		'elements.quickpost.button' : true,
		'elements.quickpost.htmlbuttons' : true,
		'elements.quickpost.htmlbuttons.extended' : false,
		'elements.quickpost.htmlbuttons.gfcode' : false,
		'elements.quickpost.htmlbuttons.breaktags' : true,
		'elements.quickpost.otherbuttons' : true,
		'elements.quickpost.link' : true,
		'elements.quickpost.link.title' : 'QuickPost',
		'elements.quickpost.aftertopic' : 0,
		'elements.quickpost.aftermessage' : 0,
		'elements.quickpost.resetconfirm' : true,
		'elements.quickpost.resetnewsig' : false,
		'elements.quickpost.blankPostWarning' : true,
		'elements.titlechange' : true,
		'elements.titleprefix' : false,
		'elements.msgnum' : true,
		'elements.msgnum.style' : 0,
		'elements.tracked.boardlink' : true,
		'elements.charcounts' : true,
		'elements.charmap' : true,
		'elements.topics.lastpostlink' : true,
		'elements.marktc' : true,
		'elements.marktc.marker' : '(tc)',
		'elements.favorites' : true,
		'elements.clock' : true,
		'elements.aml.marknewposts' : true,
		'elements.aml.pagejumper' : true,
		'elements.deletelink' : true,
		'elements.filterlink' : true,
		'elements.quotelink' : true,
		'elements.boardnav' : true,
		'elements.statusspans' : true,
		'elements.sigspans' : true,
		'elements.postidQuoteLinks' : true,
		'elements.tti' : false,

		'msgsPerPage' : 50,
		'tpcsPerPage' : 50,
		'msgSortOrder' : 1,
		'tpcSortOrder' : 4,
		'msgDisplay' : 0,
		'timeZone' : 0,
		'catShow' : true,

		'quote.header.italic' : false,
		'quote.header.bold' : true,
		'quote.header.date' : false,
		'quote.header.username' : true,
		'quote.header.messagenum' : true,
		'quote.message.italic' : true,
		'quote.message.bold' : false,
		'quote.removesignature' : true,
		'quote.style' : 0,
		'quote.controlwhitespace' : true,

		'sigs' : [{'accounts':'', 'boards':'', 'body':''}],
		'signature.newline' : false,
		'signature.applyeverywhere' : true,
		'signature.addition' : 2,
		'signature.selectMostSpecific' : true,

		'theme.disablegamefaqscss' : false,
		'styles' : [
			'gamefox-character-map.css',
			'gamefox-essentials.css',
			'gfcode.css',
			'gamefox-quickpost.css',
			'gamefox-quickwhois.css',
			'gamefox-ads.css'
		],

		'userlist.topics.showgroupnames' : false,
		'userlist.messages.showgroupnames' : true,
		'userlists' : [],

		'favorites' : {},
		'favorites.enabled' : true,

		'tracked' : {},
		'tracked.rssUrl' : {},
		'tracked.enabled' : true,

		'accounts' : [],
		'accounts.current' : '',

		'dateOffset' : 0,
		'date.enableFormat' : false,
		'date.topicPreset' : 0,
		'date.topicCustom' : '',
		'date.messagePreset' : 0,
		'date.messageCustom' : '',
		'date.clockPreset' : 0,
		'date.clockCustom' : '',

		'topic.dblclick' : 0,
		'message.dblclick' : false,
		'message.header.dblclick' : 0,
		'myposts.dblclick' : 0,
		'paging.auto' : true,
		'paging.location' : 2,
		'paging.prefix' : '[Pages: ',
		'paging.separator' : ', ',
		'paging.suffix' : ']',

		'toolbar.userlinks' : true,
		'toolbar.favorites' : true,
		'toolbar.search' : true,
		'toolbar.gotoboard' : true,
		'toolbar.login' : true,
		'toolbar.accounts' : true,
		'toolbar.tracked' : true,
		'toolbar.tracked.current' : false,
		'toolbar.classic' : false,

		'version' : '0.3.5'
	};

	setpref();
}

function setpref(pref, value)
{
	if (pref) prefs[pref] = value;
	localStorage['prefs'] = JSON.stringify(prefs);
}

if (localStorage['prefs'])
	prefs = JSON.parse(localStorage['prefs']);
else
	default_prefs();

// Version compatibility crap
if (prefs.version == '0.1')
{
	prefs['toolbar.tracked.current'] = false;

	var style_list = [];

	for (var cat in prefs.styles)
		for (var i in prefs.styles[cat])
			style_list.push(prefs.styles[cat][i]);

	prefs.styles = style_list;

	for (var i in prefs.userlists)
		for (var item in prefs.userlists[i])
		{
			if (item.search(/(type|topics|messages)/) == -1)
				continue;

			switch (prefs.userlists[i][item])
			{
				case 'users':
					prefs.userlists[i][item] = 0;
					break;
				case 'titleContains':
					prefs.userlists[i][item] = 1;
					break;
				case 'postContains':
					prefs.userlists[i][item] = 2;
					break;
				case 'highlight':
					prefs.userlists[i][item] = 0;
					break;
				case 'remove':
					prefs.userlists[i][item] = 1;
					break;
				case 'nothing':
					prefs.userlists[i][item] = (item == 'topics' ? 2 : 3);
					break;
				case 'collapse':
					prefs.userlists[i][item] = 2;
					break;
			}
		}

	prefs.tracked = {};
	prefs['tracked.rssUrl'] = {};
	delete prefs['tracked.lastAccount'];
}

if (prefs.version == '0.1' || prefs.version == '0.2')
{
	delete prefs['options.main.selectedtab'];
	delete prefs['options.signatures.selectedtab'];
	delete prefs['options.mouse.selectedtab'];
	delete prefs['options.topics.selectedtab'];

	if (typeof prefs['paging.location'] != 'number')
		prefs['paging.location'] = 2;
}

if (prefs.version != '0.3.5')
{
	for (var i in prefs.userlists)
	{
		if (typeof prefs.userlists[i].topics != 'number')
			prefs.userlists[i].topics = parseInt(prefs.userlists[i].topics);

		if (typeof prefs.userlists[i].messages != 'number')
			prefs.userlists[i].messages = parseInt(prefs.userlists[i].messages);
	}

	prefs['elements.tti'] = false;
	setpref('version', '0.3.5');
}

chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
	for (var i in request)
	{
		switch (i)
		{
			case 'set':
				setpref(request[i][0], request[i][1]);
				break;
			case 'tab':
				chrome.tabs.create({'url': request[i][0], 'selected': request[i][1]});
				break;
			case 'prefs':
				sendResponse(prefs);
				break;
			case 'history':
				chrome.history.getVisits({'url': request[i]}, function(visits) {
					sendResponse({'v': visits.length > 0});
				});
				break;
			case 'track':
				gamefox_tracked.updateList();
				break;
		}
	}
});

// disable or update tracked topics
if (!prefs['tracked.enabled'])
{
  prefs['tracked.rssUrl'] = {};
  setpref('tracked', {});
}
else if (prefs['accounts.current'])
  gamefox_tracked.updateList();

// disable favorites
if (!prefs['favorites.enabled'])
  setpref('favorites', {});
