/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2009, 2010 Brian Marshall, Michael Ryan
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var gamefox_tracked =
{
  updateList: function(callback)
  {
    // TODO: Change this when Chrome's cookie api is stable
    if (!prefs['accounts.current'])
    {
      alert('Could not update your tracked topics because you aren\'t logged in.');
      return;
    }

    // Because of how the RSS feed works without cookies, we could have an
    // option to always update from a certain account. This won't work well for
    // removing or adding tracked topics though.
    if (prefs['tracked.lastAccount'] != prefs['accounts.current'])
    { // cached url is out of date
      var request = new XMLHttpRequest();
      request.open('GET', 'http://www.gamefaqs.com/boards/tracked.php');
      request.onreadystatechange = function()
      {
        if (request.readyState == 4)
        {
          var url = /<link rel="alternate"[^>]*href="(http:\/\/www\.gamefaqs\.com\/boards\/tracked\.xml\?user=\d+&key=[^"]+)" \/>/
            .exec(request.responseText);
          if (url)
          {
            url = url[1];

            // cache it
            setpref('tracked.rssUrl', url);
            setpref('tracked.lastAccount', prefs['accounts.current']);

            gamefox_tracked.grabFromRSS(url, callback);
          }
        }
      }
      request.send(null);
    }
    else
    {
      // use cached url
      gamefox_tracked.grabFromRSS(prefs['tracked.rssUrl'], callback);
    }
  },

  grabFromRSS: function(url, callback)
  {
    var request = new XMLHttpRequest();
    request.open('GET', url);
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        var year = new Date().getFullYear();
        var prevLastPost = 0;

        var xmlobject = (new DOMParser()).parseFromString(request.
            responseText.substr(request.responseText.indexOf('>') + 1), 'text/xml');

        var items = xmlobject.getElementsByTagName('item');
        var list = {};
        for (var i = 0; i < items.length; i++)
        {
          var ids = gamefox_utils.parseBoardLink(items[i].
              getElementsByTagName('link')[0].textContent);
          var bid = ids.board;
          var tid = ids.topic;
          var title = items[i].getElementsByTagName('title')[0].textContent;

          // keep hold status
          if (prefs.tracked[ids['board']]
              && prefs.tracked[ids['board']].topics[ids['topic']]
              && prefs.tracked[ids['board']].topics[ids['topic']].hold)
            var hold = true;
          else
            var hold = false;

          var topic = {
            title: title.substr(0, title.lastIndexOf('-') - 2),
            age: title.substr(title.lastIndexOf('-') + 2),
            hold: hold,
            deleted: false,
            newPosts: false
          };
          var data = new Array(
              'Last Post', 'lastPost',
              'Messages', 'msgs',
              'Board', 'board'
              );
          var desc = items[i].getElementsByTagName('description')[0].
            textContent;
          for (var j = 0; j < data.length; j += 2)
          {
            topic[data[j + 1]] = gamefox_utils.trim(
                (new RegExp(data[j] + ': ([^\\0]*?)\n')).
                exec(desc)[1].replace(/<br \/>/g, ''));
          }

          // check for year change
          if (prevLastPost != 0 &&
              prevLastPost < gamefox_date.strtotime(topic.lastPost).getTime())
          {
            // this entry is more recent than the last entry, which should
            // only happen when the year is different
            --year;
          }
          prevLastPost = gamefox_date.strtotime(topic.lastPost).getTime();
          topic.lastPostYear = year;

          // check for new posts
          if (prefs.tracked[bid] && prefs.tracked[bid].topics[tid]
              && topic.lastPost != prefs.tracked[bid].topics[tid]
                .lastPost)
            topic.newPosts = true;

          if (!list[ids['board']])
            list[ids['board']] = {name: topic['board'], topics: {}};
          list[ids['board']]['topics'][ids['topic']] = topic;
        }

        // check deleted topics
        for (var i in prefs.tracked)
        {
          for (var j in prefs.tracked[i].topics)
          {
            if (list[i] && list[i].topics[j]) continue; // topic still exists

            var topic = prefs.tracked[i].topics[j];

            if (!topic.hold) continue; // topic isn't held

            if (!list[i])
            {
              // board has been removed from tracked list
              list[i] = {name: prefs.tracked[i].name, topics: {}};
            }

            topic.deleted = true;
            list[i].topics[j] = topic;
          }
        }

	      setpref('tracked', list);
        if (callback)
        {
          callback();
        }
      }
    }
    request.send(null);
  },

  holdTopic: function(board, topic)
  {
    if (!bg.prefs.tracked[board].topics[topic])
      return;

    bg.prefs.tracked[board].topics[topic].hold = !bg.prefs.tracked[board].topics[topic].hold;
    bg.setpref();
  },

  deleteTopic: function(boardId, topicId)
  {
    var topic = bg.prefs.tracked[boardId].topics[topicId];
    if (!topic.deleted)
    {
      var request = new XMLHttpRequest();
      request.open('GET', gamefox_utils.linkToTopic(boardId, topicId) + '?action=stoptrack');
      request.onreadystatechange = function()
      {
        if (request.readyState == 4)
        {
          if (request.responseText.indexOf('no longer tracking') != -1)
            gamefox_tracked.updateList();
          else
            alert('An error occurred untracking this topic.');
        }
      }
      request.send(null);
    }
    else
    {
      delete bg.prefs.tracked[boardId].topics[topicId];

      if (!bg.prefs.tracked[boardId].topics.__count__)
        delete bg.prefs.tracked[boardId]; // board is empty

      bg.setpref();
    }
  }
};
