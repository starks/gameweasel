/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2009 Brian Marshall
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var dateFormat =
{
  init: function()
  {
    // Populate menus with formats
    
    var types = ['topic', 'message', 'clock'];
    var type, formatMenu, formats, formatPreset, item, customTextbox;

    for (var i in types)
    {
      type = types[i];
      customTextbox = document.getElementById('date.' + type + 'Custom');
      formatMenu = document.getElementById('date.' + type + 'Preset');
      formats = bg.date.listFormats(type);
      formatPreset = prefs['date.' + type + 'Preset'];
      for (var j in formats)
      {
        item = document.createElement('option');
        formatMenu.appendChild(item);
        item.innerHTML = bg.date.parseFormat(null, formats[j]);
        item.value = j;
      }

      item = document.createElement('option');
      formatMenu.appendChild(item);
      item.value = -1;

      // Activate custom format textbox
      if (formatPreset != -1)
        customTextbox.disabled = true;

      // Preview custom formats
      this.previewCustom(customTextbox);
    }
  },

  change: function(menu)
  {
    var type = menu.id.substr(5, menu.id.indexOf('P') - 5);;

    if (menu.selectedIndex == menu.lastChild.index) // enable custom textbox
      document.getElementById('date.' + type + 'Custom').disabled = false;
    else
      document.getElementById('date.' + type + 'Custom').disabled = true;
  },

  previewCustom: function(textbox)
  {
    var type = textbox.id.substr(5, textbox.id.indexOf('C') - 5);
    var item = document.getElementById('date.' + type + 'Preset').lastChild;

    if (!prefs['date.' + type + 'Custom'].length)
      item.innerHTML = 'Custom';
    else
      item.innerHTML = 'Custom - '
        + bg.date.parseFormat(null, prefs['date.' + type + 'Custom']);
  },
};
