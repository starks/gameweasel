var bg = chrome.extension.getBackgroundPage();

var zones = {
	'-720': 'GMT -12:00',
	'-660': 'GMT -11:00',
	'-600': 'GMT -10:00',
	'-540': 'GMT -9:00',
	'-480': 'GMT -8:00',
	'-420': 'GMT -7:00',
	'-360': 'GMT -6:00',
	'-300': 'GMT -5:00',
	'-240': 'GMT -4:00',
	'-210': 'GMT -3:30',
	'-180': 'GMT -3:00',
	'-120': 'GMT -2:00',
	'-60': 'GMT -1:00',
	'0': 'GMT',
	'60': 'GMT +1:00',
	'120': 'GMT +2:00',
	'180': 'GMT +3:00',
	'240': 'GMT +4:00',
	'300': 'GMT +5:00',
	'330': 'GMT +5:30',
	'360': 'GMT +6:00',
	'390': 'GMT +6:30',
	'420': 'GMT +7:00',
	'480': 'GMT +8:00',
	'540': 'GMT +9:00',
	'570': 'GMT +9:30',
	'600': 'GMT +10:00',
	'660': 'GMT +11:00',
	'720': 'GMT +12:00',
	'780': 'GMT +13:00'
};

function toggle(that)
{
	var tog = that.nextSibling;

	if (tog.style.display == 'none')
		tog.style.display = 'block';
	else
		tog.style.display = 'none';
}

function load_prefs()
{
	for (var i in bg.prefs)
	{
		var opt = document.getElementById(i);

		if (opt) switch (typeof bg.prefs[i])
		{
			case 'boolean':
				opt.checked = bg.prefs[i];
				break;
			case 'string':
				opt.value = bg.prefs[i];
				break;
			case 'number':
				if (i.search(/date\.(topic|message|clock)Preset/) != -1)
					opt.selectedIndex = (bg.prefs[i] != -1) ? bg.prefs[i] : opt.lastChild.index;
				else if (i.search(/(msgs|tpcs)PerPage/) != -1)
					opt.selectedIndex = bg.prefs[i] / 10 - 1;
				else if (i.search(/((msg|tpc)SortOrder|signature\.addition)/) != -1)
					opt.selectedIndex = bg.prefs[i] - 1;
				else if (i.search(/(topic|myposts)\.dblclick/) != -1 && bg.prefs[i] >= 4)
					opt.selectedIndex = bg.prefs[i] - 1;
				else if (i == 'timeZone')
				{
					var j = (bg.prefs[i] >= 0 ? 13 : -17);
					for (var z in zones)
					{
						if (bg.prefs[i].toString() == z)
						{
							opt.selectedIndex = j;
							break;
						}

						j ++;
					}
				}
				else
					opt.selectedIndex = bg.prefs[i];
				break;
		}
	}

	for (var i in bg.prefs.styles)
		document.getElementById(bg.prefs.styles[i]).checked = true;

	for (var i in bg.prefs.usercss)
		document.getElementById('custom-' + bg.prefs.usercss[i][0]).checked = bg.prefs.usercss[i][1];

	for (var i in bg.prefs.sigs)
	{
		for (var j in bg.prefs.sigs[i])
		{
			if (bg.prefs.sigs[i][j] == '') continue;
			document.getElementById('sigs.' + i + '.' + j).value = bg.prefs.sigs[i][j];

			if (j == 'body')
				sigCharsUpdate(document.getElementById('sigs.' + i + '.body'));
		}
	}

	for (var i in bg.prefs.userlists)
		for (var j in bg.prefs.userlists[i])
		{
			var item = document.getElementById(['userlists', i, j].join('.'));

			if (item.nodeName == 'select')
				item.selectedIndex = bg.prefs.userlists[i][j];
			else
				item.value = bg.prefs.userlists[i][j];
		}

	for (var i in bg.prefs.accounts)
	{
		document.getElementById('accounts.' + i + '.name').value = bg.prefs.accounts[i].name;
		document.getElementById('accounts.' + i + '.pass').value = bg.prefs.accounts[i].pass;
	}

	for (var i in {'elements.titlechange':null, 'date.enableFormat':null, 'paging.auto':null, 'elements.tti':null,
		'elements.msgnum':null, 'elements.marktc':null, 'toolbar.tracked':null})
	{
		if (!bg.prefs[i])
	 		toggle(document.getElementById(i).nextSibling);
	}
}

function save_pref(that)
{
	if (that.id.split('.')[0] == 'userlists')
	{
		if (that.id.split('.')[2] == 'name')
			that.parentNode.parentNode.previousSibling.innerHTML = that.value || 'Group ' + (parseInt(that.id.split('.')[1]) + 1);

		savegroup(that);
		return;
	}

	switch (typeof bg.prefs[that.id])
	{
		case 'boolean':
			bg.setpref(that.id, that.checked);
			break;
		case 'string':
			bg.setpref(that.id, that.value);
			break;
		case 'number':
			bg.setpref(that.id, parseInt(that.value));
			break;
	}
}

function save_css(that)
{
	if (that.id.indexOf('custom-') == 0)
	{
		for (var i in bg.prefs.usercss)
			if (bg.prefs.usercss[i][0] == that.id.substr(7)) // ??? ??? ???
			{
				bg.prefs.usercss[i][1] = that.checked;
				break;
			}

		bg.setpref();
		return;
	}

	if (that.checked)
	{
		var conflicts = ['capitalized-message-links', 'message-link-icons',
		    'hide-signatures', 'remove-signatures', 'status-default', 'status-classic'];

		for (var i in conflicts)
		{
			if (that.id != conflicts[i] + '.css') continue;
			i = parseInt(i);

			var other = document.getElementById(conflicts[(i % 2) ? (i - 1) : (i + 1)] + '.css');
			other.checked = false;
			save_css(other);
		}

		bg.prefs.styles.push(that.id);
	}
	else
		for (var i in bg.prefs.styles)
			if (bg.prefs.styles[i] == that.id)
				bg.prefs.styles.splice(i, 1);

	bg.setpref();
}

function gamefox_css()
{
	var serialized = prompt('Copy the value of "gamefox.theme.css.serialized" from Firefox\'s about:config, and paste it here:');
	if (!serialized) return;

	if (serialized.search('gamefox.theme.css.serialized;') != -1)
		serialized = serialized.split(';')[1];

	try {
		var css = JSON.parse(serialized);

		if (!css.gamefox || !css.bundled)
			call_nonexistent_function_to_produce_error();
	}
	catch(e) {
		alert('Invalid gamefox.theme.css.serialized string');
		return;
	}

	bg.prefs.styles = [];

	for (var cat in {'gamefox':null, 'bundled':null})
		for (var file in css[cat])
			if (css[cat][file]['enabled'].toString() == 'true')
				bg.prefs.styles.push(file);

	bg.setpref();
	load_prefs();
}

function add_node(list, par)
{
	if (typeof list == 'string')
	{
		var li = document.createElement('li');
		par.appendChild(li);
		li.innerHTML = list;
	}
	else if (!list.length)
	{
		for (var catname in list)
		{
			var li = document.createElement('li');
			par.appendChild(li);

			if (catname.indexOf(':') != -1)
			{
				var pair = catname.split(':');
				li.innerHTML = '<input type="checkbox" id="' + pair[0] + '" onchange="save_pref(this); toggle(this.nextSibling);" />'
					+ '<label for="' + pair[0] + '">' + pair[1] + '</label>';
			}
			else
			{
				li.innerHTML = '<label onclick="toggle(this);">' + catname + '</label>';
			}

			add_node(list[catname], li);
		}
	}
	// This does what it needs to, but it should probably be rewritten.
	else if (list.length && typeof list[0] == 'string' && (bg.prefs[list[0]] != undefined || list[0].search(/.+\.css/) != -1 || list[0].search(/^(sigs|userlists)\..+/) != -1))
	{
		var li = document.createElement('li');
		par.appendChild(li);

		if (list[0].search(/.+\.css/) != -1)
		{
			li.innerHTML = '<input type="checkbox" id="' + list[0] + '" onchange="save_css(this);" />'
			+ '<label for="' + list[0] + '">' + list[1] +'</label>';

			if (list[3]) li.innerHTML += ' - By ' + list[3];
			li.innerHTML += '<div class="css_desc">' + list[2] + '</div>';
			
		}
		else if (list[0].search(/sigs\..+/) != -1)
		{
			li.innerHTML = '<label for="' + list[0] + '">' + list[1] + ': </label><input type="text" id="' + list[0] + '" onchange="savegroup(this);" /><br /><div>' + list[2] + '</div>';
		}
		else
		{
		var t = list[0].split('.');
		var x = bg.prefs[list[0]] != undefined ? typeof bg.prefs[list[0]] : typeof bg.prefs[t[0]][t[1]][t[2]];

		switch ((list.length > 2) ? 'number' : x)
		{
			case 'boolean':
				li.innerHTML = '<input type="checkbox" id="' + list[0] + '" onchange="save_pref(this);" /><label for="' + list[0] + '">' + list[1] + '</label>';
				break;
			case 'string':
				li.innerHTML = '<label for="' + list[0] + '">' + list[1] + ': </label><input type="text" id="' + list[0] + '" onchange="save_pref(this);" />';
				if (t[2] == 'color')
				{
					document.getElementById(list[0]).removeAttribute('type');
					document.getElementById(list[0]).className = 'color {hash:true}';
				}
				break;
			case 'number':
				li.innerHTML='<label for="' + list[0] + '">' + list[1] + ': </label>';
				var sel = document.createElement('select');
				li.appendChild(sel);
				sel.id = list[0];
				sel.setAttribute('onchange', 'save_pref(this);');

				// Do two iterations to put timezone list in the right order
				for (var i in list[2])
				{
					if (!list[2][i] || parseInt(i) >= 0) continue;

					var opt = document.createElement('option');
					sel.appendChild(opt);
					opt.innerHTML = list[2][i];
					opt.value = i;
				}
				for (var i in list[2])
				{
					if (!list[2][i] || parseInt(i) < 0) continue;

					var opt = document.createElement('option');
					sel.appendChild(opt);
					opt.innerHTML = list[2][i];
					opt.value = i;
				}
				break;
		} }
	}
	else
	{
		var ul = document.createElement('ul');
		par.appendChild(ul);

		for (var i in list)
		{
			add_node(list[i], ul);
		}
	}
}

function newsig()
{
	bg.prefs.sigs.push({'accounts':'', 'boards':'', 'body':''});
	bg.setpref();
	document.location.reload();
}

function hl_addgroup()
{
	bg.prefs.userlists.push({
		'name': '',
		'color': '#CCFFFF',
		'type': 0,
		'users': '',
		'topics': 0,
		'messages': 0
	});

	bg.setpref();
	document.location.reload();
}

function add_account()
{
	bg.prefs.accounts.push({
		'name': '',
		'pass': ''
	});

	bg.setpref();
	document.location.reload();
}

function savegroup(that)
{
	var parts = that.id.split('.');

	bg.prefs[parts[0]][parts[1]][parts[2]] = (typeof bg.prefs[parts[0]][parts[1]][parts[2]] != 'number') ? that.value : parseInt(that.value);
	bg.setpref();

	if (parts[0] == 'accounts' && parts[2] == 'name')
		that.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.previousSibling.innerHTML = that.value;
}

function delgroup(type, n)
{
	bg.prefs[type].splice(n, 1);
	bg.setpref();
	document.location.reload();
}

var datebox = '\
<table id="date">\
	<tr>\
		<td><label for="date.topicPreset">Topic lists: </label></td>\
		<td><select id="date.topicPreset" onchange="save_pref(this); dateFormat.change(this);"></select></td>\
		<td><input type="text" id="date.topicCustom" onchange="save_pref(this); dateFormat.previewCustom(this);" /> <a href="strftime.html">?</a></td>\
	</tr>\
	<tr>\
		<td><label for="date.messagePreset">Message lists: </label></td>\
		<td><select id="date.messagePreset" onchange="save_pref(this); dateFormat.change(this);"></select></td>\
		<td><input type="text" id="date.messageCustom" onchange="save_pref(this); dateFormat.previewCustom(this);" /> <a href="strftime.html">?</a></td>\
	</tr>\
	<tr>\
		<td><label for="date.clockPreset">Clock: </label></td>\
		<td><select id="date.clockPreset" onchange="save_pref(this); dateFormat.change(this);"></select></td>\
		<td><input type="text" id="date.clockCustom" onchange="save_pref(this); dateFormat.previewCustom(this);" /> <a href="strftime.html">?</a></td>\
	</tr>\
</table>';

var paging = '\
	<label for="paging.prefix">Prefix: </label><input type="text" id="paging.prefix" onchange="save_pref(this);" />\
	<label for="paging.separator">Delimiter: </label><input type="text" id="paging.separator" onchange="save_pref(this);" />\
	<label for="paging.suffix">Suffix: </label><input type="text" id="paging.suffix" onchange="save_pref(this);" />';


var grab_save = '<button onclick="importBoardSettings(this);">Grab from GameFAQs</button>\
<button onclick="exportBoardSettings(this);">Save to GameFAQs</button>';

var tree = {
	'Elements' : [{
		'All Pages' : [
			{'elements.titlechange:Custom window titles':
				[['elements.titleprefix', 'Window title page prefixes']]},
			['elements.favorites', 'Add favorites menu'],
			['elements.clock', 'Add clock'],
			{'date.enableFormat:Custom date formats' : [datebox]}
		],
		'Topic Lists' : [
			['elements.topics.lastpostlink', 'Link to last post'],
	    		{'paging.auto:Link to individual pages' : [
				['paging.location', 'Show links',
					['In a new row below the topic title', 'Right of the topic title', 'Below the topic title']],
				paging
			]},
			['elements.tracked.boardlink', 'Link to boards on tracked topics page'],
			['elements.aml.marknewposts', 'Label new posts on active messages page'],
			['elements.aml.pagejumper', 'Page jumper on active messages page'],
			['topic.dblclick', 'When double clicking on topic list row',
				['Do nothing', 'Show links to topic pages', 'Go to last post', null, 'Go to last page', 'Track topic']],
			['myposts.dblclick', 'When double clicking on active message list row',
				['Do nothing', 'Show links to topic pages', 'Go to last post', null, 'Go to last page', 'Track topic']]
		],
		'Message Lists' : [
			['elements.boardnav', 'Navigation links at bottom of page'],
			{
				'elements.tti:Convert image URLs to thumbnails' : [
					['elements.tti.x', 'Thumbnail width'],
					['elements.tti.y', 'Thumbnail height'],
					['elements.tti.hoverx', 'Width on hover'],
					['elements.tti.hovery', 'Height on hover'],
					'<span class="small" style="padding-left: 0px">Set width/height to 0 for the original size.  Click an image to fully expand it, double click to go to the image\'s URL.</span>'
				],
				'Message header links' : [
					['elements.deletelink', 'Delete/Close'],
					['elements.filterlink', 'Filter'],
					['elements.quotelink', 'Quote']
				],
				'elements.msgnum:Number messages' : [['elements.msgnum.style', 'Format', [
					'message detail (link), #001',
					'#001, message detail (link)',
					'#001 (link)',
					'message #001 (link)'
				]]],
				'elements.marktc:Label topic creator' : [['elements.marktc.marker', 'Label']]
			},
			['elements.postidQuoteLinks', 'Link post numbers in quotes'],
			['message.dblclick', 'Double click message body to quote message'],
			['message.header.dblclick', 'When double clicking on message header',
				['Do nothing', 'Show QuickWhois', 'Quote message', 'Filter messages']]
		],
		'Posting' : [
			['elements.quickpost.button', 'Post Message button'],
			['elements.charcounts', 'Character counters'],
			['elements.charmap', 'Character map'],
			{'HTML tag buttons' : [
				['elements.quickpost.htmlbuttons', 'Standard'],
				['elements.quickpost.htmlbuttons.extended', 'Extended'],
				['elements.quickpost.htmlbuttons.gfcode', 'GFCode'],
				['elements.quickpost.htmlbuttons.breaktags', 'Break HTML']
			]}
		]
	}],
	'QuickPost' : [
		{'elements.quickpost.link:Topic QuickPost':
			[['elements.quickpost.link.title', 'Link label']]
		},
		['elements.quickpost.form', 'Message QuickPost'],
		['elements.quickpost.otherbuttons', 'Preview and reset buttons'],
		['elements.quickpost.resetconfirm', 'Confirm resetting post'],
		['elements.quickpost.resetnewsig', 'Choose a new signature when resetting post'],
		['elements.quickpost.blankPostWarning', 'Warn me before making a blank post'],
		['elements.quickpost.aftertopic', 'After QuickPosting a topic', ['Go to topic', 'Go to board']],
		['elements.quickpost.aftermessage', 'After QuickPosting a message', ['Go to last post', 'Go back to same page', 'Go to first page', 'Go to board']]
	],
	'Quoting' : [
		{'Quote header' : [
			['quote.header.username', 'Include Username'],
			['quote.header.date', 'Include Date'],
			['quote.header.messagenum', 'Include Post Number']
		], 'Quote style' : [
			['quote.header.bold', 'Bold header'],
			['quote.header.italic', 'Italicize header'],
			['quote.message.bold', 'Bold message'],
			['quote.message.italic', 'Italicize message']
		]},
		['quote.removesignature', 'Remove signature'],
		['quote.style', 'Format quote with',
			['GFCode tags (&lt;i&gt;, &lt;p&gt;, and &lt;strong&gt;)', 'Classic tags (&lt;b&gt; and &lt;i&gt;)']]
	],
	'Toolbar menu' : [
		['toolbar.userlinks', 'User links'],
		['toolbar.accounts', 'Account switcher'],
		['toolbar.login', 'Login form'],
		['toolbar.search', 'Game search'],
		['toolbar.gotoboard', 'Go to board ID'],
		['toolbar.favorites', 'Favorite boards list'],
		{'toolbar.tracked:Tracked topics list' :
			[['toolbar.tracked.current', 'Only show topics tracked by current account']]},
		['toolbar.tti', 'TTI Switch'],
		['toolbar.classic', 'Classic GameFAQs style']
	],
	/*'context:Context Menu' : [{
		'Main' : [
			['context.pagelist', 'Pages'],
			['context.track', 'Track Topic'],
			['context.quote', 'Quote'],
			['context.filter', 'Filter'],
			['context.delete', 'Delete/Close'],
			['context.usergroups', 'User Groups'],
			['context.breaktags', 'Break HTML']
		],
		'Submenus' : [
			['context.sidebar', 'Sidebar'],
			['context.taglist', 'Tags'],
			['context.tracked', 'Tracked'],
			['context.accounts', 'Accounts'],
			['context.favorites', 'Favorites'],
			['context.links', 'Links']
		]
	}],*/
	'Board Settings' : [
		['tpcsPerPage', 'Topics per page', {'10':'10', '20':'20', '30':'30', '40':'40', '50':'50'}],
		['tpcSortOrder', 'Topic sort', {
			'1':'By first post, oldest first',
			'2':'By first post, newest first',
			'3':'By last post, oldest first',
			'4':'By last post, newest first'
		}],
		['msgsPerPage', 'Messages per page', {'10':'10', '20':'20', '30':'30', '40':'40', '50':'50'}],
		['msgSortOrder', 'Message sort', {'1':'Oldest first', '2':'Newest first'}],
		['timeZone', 'Time zone', zones],
		['msgDisplay', 'Message poster display', ['Left of message', 'Above message']],
		['catShow', 'Show category list'],
		grab_save
	],
	'Stylesheets' : [{
		'Themes' : [
			['8for11.css', '8for11', 'This version is not supported by TakatoMatsuki.<br />\
				Make GameFAQs look like v8 (pre-2004).<br />\
				Message Poster Display must be Above Message (Main -> Board Settings)<br />\
				The "Status icons (classic)" stylesheet is recommended.<br />\
				GameFAQs must be using the V10 style.',
           				'TakatoMatsuki, Swordless Link'],
			['ricapar.css', 'Classic',
				'Emulates the 2001-2004 style of GameFAQs. Disable main GameFAQs stylesheets to use.', 'Ricapar et al.'],
			['gfpastel-2010.css', 'GFPastel 2010',
				'A modern stylesheet in pastel blues and purples. Disable main GameFAQs stylesheets to use.', 'spynae'],
			['spotfaqs-extras.css', 'SpotFAQs extras', 'This version is not supported by TakatoMatsuki.<br />\
				Styles GameChrome features.<br />\
				Designed to be used with the SpotFAQs skin on GameFAQs.', 'TakatoMatsuki'],
			['wide-layout.css', 'Wide default',
				'Increases the width of the page to fill the whole window. Works with the default GameFAQs skin.']
		],
		'Tweaks' : [
			['gamefox-ads.css', 'Ad blocking', 'Hides ads and ad-related page elements. Best used with an ad blocking extension.'],
			['ascii-art-font.css', 'ASCII art font', 'Increases the font size of messages to make ASCII art look better.'],
			['FAQ-frames.css', 'FAQ frames', 'Styles the FAQ headers to look more like GameFAQs.', 'selmiak'],
			['hide-signatures.css', 'Hide signatures', 'Hides signatures in posts and shows them again when hovered over.'],
			['remove-signatures.css', 'Remove signatures', 'Removes signatures in posts.'],
			['capitalized-message-links.css', 'Capitalized message links', 'Capitalizes the links in message headers.'],
			['message-link-icons.css', 'Message link icons',
				'Converts links in the message header (message detail, delete, filter, quote) to icons.<br />\
				Icons courtesy of http://www.pinvoke.com/', 'Poo Poo Butter'],
			['status-default.css', 'Status icons (normal)',
				'Only show topic status icons for closed/sticky topics. This CSS conflicts with "Status icons (classic)".'],
			['status-classic.css', 'Status icons (classic)',
				'Only show topic status icons for closed/sticky topics - emulates the pre-2006 style of icons. \
				This CSS conflicts with "Status icons (normal)".']
		],
		'GameChrome Features' : [
			['gamefox-essentials.css', 'Essentials', 'Styles GameChrome features, should always be enabled.'],
			['gfcode.css', 'GFCode', 'Adds quote and code elements to posts.', 'Ant P.'],
			['gamefox-character-map.css', 'Character map', 'Makes the character map look pretty.'],
			['gamefox-quickpost.css', 'QuickPost', 'Makes QuickPost look pretty.'],
			['gamefox-quickwhois.css', 'QuickWhois', 'Makes QuickWhois look pretty.']
		],
		'Custom' : [
			'<label for="import_css">Import stylesheet: </label><input type="file" id="import_css" onchange="import_file(this, import_css);" />'
		]},
		['theme.disablegamefaqscss', 'Disable main GameFAQs stylesheets']
		
	],
	'Signatures' : [
		{},
		'<button onclick="newsig();">Add signature</button>',
		['signature.applyeverywhere', 'Replace GameFAQs signature on standard post page'],
    		['signature.newline', 'Insert an additional line break before the separator'],
		['signature.selectMostSpecific', 'Select signatures with the most specific account and board settings'],
		['signature.addition', 'Append signature after', {'2':'Page has loaded', '1':'Post is submitted'}]
	],
	'Highlighting' : [
		{},
		'<button onclick="hl_addgroup();">Add Group</button>',
		['userlist.topics.showgroupnames', 'Show group names on topic lists'],
		['userlist.messages.showgroupnames', 'Show group names on message lists']
	],
	'Accounts' : [
		{},
		'<button onclick="add_account();">Add Account</button> <strong>Warning: Passwords will be stored unencrypted on your hard disk.</strong>'
	],
	'Manage Settings' : [
		'<label for="import">Import settings: </label><input type="file" id="import" onchange="import_file(this, import_prefs);" />',
		//'<label for="export">Export settings: </label><input type="file" id="export" onchange="export_prefs(this);" />',
		'<button onclick="gamefox_css();">Import GameFOX CSS settings</button>',
		'<button onclick="if (confirm(\'This will accidentally the whole thing.  Are you sure?\')) { bg.default_prefs(); document.location.reload();}">Restore default settings</button>'
	]
};

for (var i in bg.prefs.usercss)
	tree.Stylesheets[0].Custom.splice(tree.Stylesheets[0].Custom.length - 1, 0, ['custom-' + bg.prefs.usercss[i][0], bg.prefs.usercss[i][0],
		'<button onclick="delgroup(\'usercss\',' + i + ');">Delete</button>']);

for (var i in bg.prefs.sigs)
{
	i = parseInt(i);
	var label = (i ? 'Signature ' + i : 'Default signature');

	tree.Signatures[0][label] = [
		'<textarea id="sigs.' + i + '.body" onblur="savegroup(this);" onkeyup="sigCharsUpdate(this);"></textarea>',
		'<button id="import-' + i + '" onclick="importSig(this);">Grab from GameFAQs</button> <button id="export-' + i + '" onclick="exportSig(this);">Save to GameFAQs</button>'
			+ (i ? ' <button onclick="delgroup(\'sigs\', ' + i + ');">Delete</button>' : '') + ' <span id="sigchars.' + i + '"></span>'
	];

	if (i)
	{
		tree.Signatures[0][label].unshift(['sigs.' + i + '.boards', 'Boards',
			'<span class="small">Comma-separated list of board names and ids; if left blank, it is used for all boards.</span>']);
		tree.Signatures[0][label].unshift(['sigs.' + i + '.accounts', 'Accounts',
			'<span class="small">Comma-separated list of account names; if left blank, it is used for all accounts.</span>']);
	}
}

for (var i in bg.prefs.userlists)
{
	tree.Highlighting[0][bg.prefs.userlists[i].name || 'Group ' + (parseInt(i) + 1)] = [
		['userlists.' + i + '.name', 'Group name'],
		['userlists.' + i + '.color', 'Color'],
		'<select id="userlists.' + i + '.type" onchange="savegroup(this);"><option value="0">Username is: </option>\
			<option value="1">Title contains: </option><option value="2">Post contains: </option>\
			</select> <input type="text" id="userlists.' + i + '.users" class="userlist" onchange="savegroup(this);" />',
		'<span class="small">Separate values with commas. List (tc) as a user to highlight the topic creator.</span>',
		['userlists.' + i + '.topics', 'Topic action', ['Highlight', 'Remove', 'None']],
		['userlists.' + i + '.messages', 'Message action', ['Highlight', 'Remove', 'Collapse', 'None']],
		'<button onclick="delgroup(\'userlists\', ' + i + ');">Delete</button>'
	];
}

for (var i in bg.prefs.accounts)
{
	tree.Accounts[0][bg.prefs.accounts[i].name || 'New Account'] = [
		'<table>\
			<tr>\
				<td><label for="accounts.' + i + '.name">Universal username: </label></td><td><input type="text" id="accounts.' + i + '.name" onchange="savegroup(this);" /></td>\
			</tr><tr>\
				<td align="right"><label for="accounts.' + i + '.pass">Password: </label></td><td><input type="password" id="accounts.' + i + '.pass" onchange="savegroup(this);" /></td>\
			</tr></table>',
		'<button onclick="delgroup(\'accounts\', ' + i + ');">Delete</button>'
	];
}

function import_file(that, callback)
{
	try {
		var reader = new FileReader();
		reader.readAsText(that.files[0], 'UTF-8');
		reader.onload = callback;
		reader.onerror = function() {
			alert('Error: File could not be read');
		};
	}
	catch (e) {
		alert('This feature requires Chrome 6');
	}
}

function import_css(event)
{
	var name = document.getElementById('import_css').files[0].name;
	if (name.lastIndexOf('.css') != name.length - 4)
	{
		alert('Error: File extension must be ".css"');
		return;
	}

	for (var i in bg.prefs.usercss)
		if (bg.prefs.usercss[i][0] == name)
		{
			alert('Error: A stylesheet named "' + name + '" has already been imported');
			return;
		}

	bg.prefs.usercss.push([name, true, event.target.result]);
	bg.setpref();
	document.location.reload();
}

function import_prefs(event)
{
	try {
		var prefs_new = JSON.parse(event.target.result);
	}
	catch (e) {
		alert('Error: Invalid preference file');
		return;
	}

	if (prefs_new['version'])
		delete prefs_new['version'];

	if (prefs_new['tracked.rssUrl'] && prefs_new['tracked.lastAccount'])
	{
		bg.prefs['tracked.rssUrl'][prefs_new['tracked.lastAccount']] = prefs_new['tracked.rssUrl'];
		delete prefs_new['tracked.rssUrl'];
		delete prefs_new['tracked.lastAccount'];
	}

	if (prefs_new['favorites.serialized'])
	{
		bg.prefs.favorites = JSON.parse(prefs_new['favorites.serialized']);
		for (var i in bg.prefs.favorites)
			bg.prefs.favorites[i] = bg.prefs.favorites[i].name;
	}

	if (prefs_new['signature.serialized'])
		bg.prefs.sigs = JSON.parse(prefs_new['signature.serialized']);

	if (prefs_new['userlist.serialized'])
	{
		bg.prefs.userlists = JSON.parse(prefs_new['userlist.serialized']);

		for (var i in bg.prefs.userlists)
			for (var item in bg.prefs.userlists[i])
			{
				if (item == 'include')
				{
					delete bg.prefs.userlists[i][item];
					continue;
				}

				if (item.search(/(type|topics|messages)/) == -1 || typeof bg.prefs.userlists[i][item] == 'number')
					continue;

				switch (bg.prefs.userlists[i][item])
				{
					case 'users':
						bg.prefs.userlists[i][item] = 0;
						break;
					case 'titleContains':
						bg.prefs.userlists[i][item] = 1;
						break;
					case 'postContains':
						bg.prefs.userlists[i][item] = 2;
						break;
					case 'highlight':
						bg.prefs.userlists[i][item] = 0;
						break;
					case 'remove':
						bg.prefs.userlists[i][item] = 1;
						break;
					case 'nothing':
						bg.prefs.userlists[i][item] = (item == 'topics' ? 2 : 3);
						break;
					case 'collapse':
						bg.prefs.userlists[i][item] = 2;
						break;
				}
			}
	}

	for (var i in prefs_new)
		if (bg.prefs[i] != undefined && typeof bg.prefs[i] == typeof prefs_new[i])
			bg.prefs[i] = prefs_new[i];

	bg.setpref();
	alert('Your preferences have been imported');
	document.location.reload();
}

function importSig(button)
{
    button.disabled = true;

    var request = new XMLHttpRequest();
    request.open('GET', 'http://www.gamefaqs.com/boards/sigquote.php');
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        if (request.responseText.indexOf('>Signature and Quote</h2>') == -1)
        {
	  alert('Your signature could not be imported. Check that you are logged in to GameFAQs and try again.');
          button.disabled = false;
          return;
        }

        var sig = request.responseText.match(/<textarea\b[^>]+?\bname="sig"[^>]*>([^<]*)<\/textarea>/i);
        if (!sig)
        {
	  alert('Your signature could not be imported. Maybe you have one of those really old signatures that displays bold and italics on the profile page?');
          button.disabled = false;
          return;
        }

        sig = bg.gamefox_utils.convertNewlines(bg.gamefox_utils.specialCharsDecode(sig[1]));

	var textbox = document.getElementById('sigs.' + button.id.split('-')[1] + '.body');
        textbox.value = sig;
	sigCharsUpdate(textbox);
	savegroup(textbox);

	alert('Your signature has been imported into GameChrome.');
        button.disabled = false;
      }
    };

    request.send(null);
}

function exportSig(button)
{
    button.disabled = true;

    var request = new XMLHttpRequest();
    request.open('GET', 'http://www.gamefaqs.com/boards/sigquote.php');
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        if (request.responseText.indexOf('>Signature and Quote</h2>') == -1)
        {
	  alert('Your signature could not be exported. Check that you are logged in to GameFAQs.');
          button.disabled = false;
          return;
        }

        var action = request.responseText.match(/<form\b[^>]+?\bid="add"[^>]+?\baction="([^"]*)">/);
        if (!action)
        {
	  alert('Your signature could not be exported. (no userid)');
          button.disabled = false;
          return;
        }
        action = action[1];

        var postRequest = new XMLHttpRequest();
        postRequest.open('POST', 'http://www.gamefaqs.com' + action);
        postRequest.onreadystatechange = function()
        {
          if (postRequest.readyState == 4)
          {
            if (postRequest.responseText.indexOf('<p>Signature/quote updated</p>') == -1)
            {
              if (postRequest.responseText.indexOf('<p>Your signature contains') != -1)
		alert('Your signature is too long and could not be exported.');
              else
		alert('Your signature could not be exported. (unexpected response)');
            }
            else
		alert('Your signature has been exported to GameFAQs.');

            button.disabled = false;
          }
        };

	var sigText = document.getElementById('sigs.' + button.id.split('-')[1] + '.body').value;
        var quoteText = request.responseText.match(/<textarea\b[^>]+?\bname="quote"[^>]*>([^<]*)<\/textarea>/i)[1];
        quoteText = bg.gamefox_utils.specialCharsDecode(quoteText);
        var key = request.responseText.match(/<input\b[^>]+?\bname="key"[^>]+?\bvalue="([^"]*)"[^>]*>/i)[1];

        postRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        postRequest.send(
            'sig=' + bg.gamefox_utils.URLEncode(sigText) + '&' +
            'quote=' + bg.gamefox_utils.URLEncode(quoteText) + '&' +
            'key=' + key + '&' +
            'submit=1'
        );
      }
    };

    request.send(null);
}

function sigCharsUpdate(that)
{
  var sigLength = bg.gamefox_utils.specialCharsEncode(that.value).length;
  var sigChars = document.getElementById('sigchars.' + that.id.split('.')[1]);

  sigChars.innerHTML = sigLength + '/160';
  if (sigLength > 160)
  {
    sigChars.innerHTML += ' (!!)';
    sigChars.style.setProperty('font-weight', 'bold', null);
  }
  else
    sigChars.style.setProperty('font-weight', '', null);
}

function importBoardSettings(button)
{
    button.disabled = true;

    var request = new XMLHttpRequest();
    request.open('GET', 'http://www.gamefaqs.com/boards/settings.php');
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        if (request.responseText.indexOf('Board Display Settings') == -1)
        {
	  alert('Your board display settings could not be imported. Check that you are logged in to GameFAQs.');
          button.disabled = false;
          return;
        }

        var topicPage = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'topicpage'),
            topicSort = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'topicsort'),
            messagePage = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'messagepage'),
            messageSort = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'messagesort'),
            timezone = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'timezone'),
            userDisplay = bg.gamefox_utils.parseHTMLSelect(request.responseText, 'userdisplay'),
            catShow = /<input type="checkbox" name="catshow" checked/.test(request.responseText);

        if (topicPage == null || topicSort == null || messagePage == null || messageSort == null || timezone == null || userDisplay == null)
        {
	  alert('Your board display settings could not be imported. Check that you are logged in to GameFAQs.');
          button.disabled = false;
          return;
        }

        // TODO: validate settings from GameFAQs
        bg.prefs['tpcsPerPage'] = topicPage;
        bg.prefs['tpcSortOrder'] = topicSort;
        bg.prefs['msgsPerPage'] = messagePage;
        bg.prefs['msgSortOrder'] = messageSort;
        bg.prefs['timeZone'] = timezone;
        bg.prefs['msgDisplay'] = userDisplay;
        bg.prefs['catShow'] = catShow;

	bg.setpref();
	load_prefs();

	alert('Your board display settings have been imported into GameChrome.');
        button.disabled = false;
      }
    }

    request.send(null);
}

function exportBoardSettings(button)
{
    data = {topicPage: document.getElementById('tpcsPerPage').value,
            topicSort: document.getElementById('tpcSortOrder').value,
            messagePage: document.getElementById('msgsPerPage').value,
            messageSort: document.getElementById('msgSortOrder').value,
            timezone: document.getElementById('timeZone').value,
            userDisplay: document.getElementById('msgDisplay').value,
            catShow: document.getElementById('catShow').checked};

    button.disabled = true;

    var request = new XMLHttpRequest();
    request.open('GET', 'http://www.gamefaqs.com/boards/settings.php');
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        if (request.responseText.indexOf('Board Display Settings') == -1)
        {
	  alert('Your board display settings could not be exported. Check that you are logged in to GameFAQs.');
          button.disabled = false;
          return;
        }

        var action = request.responseText.match(/<form\b[^>]+?\bid="add"[^>]+?\baction="([^"]*)">/);
        if (!action)
        {
	  alert('Your board display settings could not be exported. (no userid)');
          button.disabled = false;
          return;
        }
        action = action[1];

        var postRequest = new XMLHttpRequest();
        postRequest.open('POST', 'http://www.gamefaqs.com' + action);
        postRequest.onreadystatechange = function()
        {
          if (postRequest.readyState == 4)
          {
            if (postRequest.responseText.indexOf('Display settings updated') == -1)
            {
		alert('Your board display settings could not be exported. (unexpected response)');
            }
            else
            {
		alert('Your board display settings have been exported to GameFAQs.');
            }
            button.disabled = false;
          }
        }
        var key = request.responseText.match(/<input\b[^>]+?\bname="key"[^>]+?\bvalue="([^"]*)"[^>]*>/i);
        key = key[1];

        postRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        postRequest.send(
            'topicpage=' + data.topicPage + '&' +
            'topicsort=' + data.topicSort + '&' +
            'messagepage=' + data.messagePage + '&' +
            'messagesort=' + data.messageSort + '&' +
            'timezone=' + data.timezone + '&' +
            'userdisplay=' + data.userDisplay + '&' +
            (data.catShow ? 'catshow=on&' : '') +
            'key=' + key + '&' +
            'submit=1'
            );
      }
    };

    request.send(null);
}
