/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2010 Jesse Lentz
 *
 * This file is part of GameChrome.
 *
 * GameChrome is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameChrome is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameChrome.  If not, see <http://www.gnu.org/licenses/>.
 */

var context =
{
  target: null,

  init: function(req, pages)
  {
    if (typeof pages == 'object' && pages != null)
      pages = Math.ceil(parseInt(pages.textContent) / prefs.msgsPerPage);
    req.pages = pages;

    return function(event) {
      if (pages == null)
      {
	      port.postMessage(req);
	      return false;
      }
      context.target = event.target;

      if (gamefox_lib.onPage(document, 'messages'))
      {
	      var link = document.location.href;
      }
      else
      {
        while (context.target.nodeName != 'TR')
          context.target = context.target.parentNode;
        context.target = context.target.cells[1].getElementsByTagName('a')[0].href;

        var link = context.target;
      }
      link = gamefox_utils.parseBoardLink(link);
      req.tid = [link.board, link.topic];

      port.postMessage(req);
      return false;
    };
  }
};
