// strftime version 0.11 by Daniel Rench
// More information: http://dren.ch/strftime/
// This is public domain software

Number.prototype.pad =
	function (n,p) {
		var s = '' + this;
		p = p || '0';
		while (s.length < n) s = p + s;
		return s;
	};

Date.prototype.months = [
		'January', 'February', 'March', 'April', 'May', 'June', 'July',
		'August', 'September', 'October', 'November', 'December'
	];
Date.prototype.weekdays = [
		'Sunday', 'Monday', 'Tuesday', 'Wednesday',
		'Thursday', 'Friday', 'Saturday'
	];
Date.prototype.dpm = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

Date.prototype.strftime_f = {
		A: function (d) { return d.weekdays[d.getDay()] },
		a: function (d) { return d.weekdays[d.getDay()].substring(0,3) },
		B: function (d) { return d.months[d.getMonth()] },
		b: function (d) { return d.months[d.getMonth()].substring(0,3) },
		C: function (d) { return Math.floor(d.getFullYear()/100); },
		c: function (d) { return d.toString() },
		D: function (d) {
				return d.strftime_f.m(d) + '/' +
					d.strftime_f.d(d) + '/' + d.strftime_f.y(d);
			},
		d: function (d) { return d.getDate().pad(2,'0') },
		e: function (d) { return d.getDate().pad(2,' ') },
		F: function (d) {
				return d.strftime_f.Y(d) + '-' + d.strftime_f.m(d) + '-' +
					d.strftime_f.d(d);
			},
		H: function (d) { return d.getHours().pad(2,'0') },
		I: function (d) { return ((d.getHours() % 12 || 12).pad(2)) },
		j: function (d) {
				var t = d.getDate();
				var m = d.getMonth() - 1;
				if (m > 1) {
					var y = d.getYear();
					if (((y % 100) == 0) && ((y % 400) == 0)) ++t;
					else if ((y % 4) == 0) ++t;
				}
				while (m > -1) t += d.dpm[m--];
				return t.pad(3,'0');
			},
		k: function (d) { return d.getHours().pad(2,' ') },
		l: function (d) { return ((d.getHours() % 12 || 12).pad(2,' ')) },
		M: function (d) { return d.getMinutes().pad(2,'0') },
		m: function (d) { return (d.getMonth()+1).pad(2,'0') },
		n: function (d) { return "\n" },
		p: function (d) { return (d.getHours() > 11) ? 'PM' : 'AM' },
		R: function (d) { return d.strftime_f.H(d) + ':' + d.strftime_f.M(d) },
		r: function (d) {
				return d.strftime_f.I(d) + ':' + d.strftime_f.M(d) + ':' +
					d.strftime_f.S(d) + ' ' + d.strftime_f.p(d);
			},
		S: function (d) { return d.getSeconds().pad(2,'0') },
		s: function (d) { return Math.floor(d.getTime()/1000) },
		T: function (d) {
				return d.strftime_f.H(d) + ':' + d.strftime_f.M(d) + ':' +
					d.strftime_f.S(d);
			},
		t: function (d) { return "\t" },
/*		U: function (d) { return false }, */
		u: function (d) { return(d.getDay() || 7) },
/*		V: function (d) { return false }, */
		v: function (d) {
				return d.strftime_f.e(d) + '-' + d.strftime_f.b(d) + '-' +
					d.strftime_f.Y(d);
			},
/*		W: function (d) { return false }, */
		w: function (d) { return d.getDay() },
		X: function (d) { return d.toTimeString() }, // wrong?
		x: function (d) { return d.toDateString() }, // wrong?
		Y: function (d) { return d.getFullYear() },
		y: function (d) { return (d.getYear() % 100).pad(2) },
//		Z: function (d) { return d.toString().match(/\((.+)\)$/)[1]; },
//		z: function (d) { return d.getTimezoneOffset() }, // wrong
//		z: function (d) { return d.toString().match(/\sGMT([+-]\d+)/)[1]; },
		'%': function (d) { return '%' }
	};

Date.prototype.strftime_f['+'] = Date.prototype.strftime_f.c;
Date.prototype.strftime_f.h = Date.prototype.strftime_f.b;

Date.prototype.strftime =
	function (fmt) {
		var r = '';
		var n = 0;
		while(n < fmt.length) {
			var c = fmt.substring(n, n+1);
			if (c == '%') {
				c = fmt.substring(++n, n+1);
				r += (this.strftime_f[c]) ? this.strftime_f[c](this) : c;
			} else r += c;
			++n;
		}
		return r;
	};

/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2009 Brian Marshall
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var gamefox_date =
{
  // http://www.opengroup.org/onlinepubs/007908799/xsh/strftime.html
  formats: {
    topic:   ['%n/%e %i:%M%p',
              '%m/%d %I:%M%p',
              '%m/%d %H:%M',
              '%d/%m %I:%M%p',
              '%d/%m %H:%M'],
    message: ['%n/%e/%Y %i:%M:%S %p',
              '%m/%d/%Y %I:%M:%S %p',
              '%m/%d/%Y %H:%M:%S',
              '%d/%m/%Y %I:%M:%S %p',
              '%d/%m/%Y %H:%M:%S',
              '%Y-%m-%d %I:%M:%S %p',
              '%Y-%m-%d %H:%M:%S'],
    clock:   ['%n/%e/%Y %i:%M:%S %p',
              '%m/%d/%Y %I:%M:%S %p',
              '%m/%d/%Y %H:%M:%S',
              '%d/%m/%Y %I:%M:%S %p',
              '%d/%m/%Y %H:%M:%S',
              '%Y-%m-%d %I:%M:%S %p',
              '%Y-%m-%d %H:%M:%S']
  },

  getFormat: function(type, id)
  {
    if (id == -1)
      return gamefox_lib.getPref('date.' + type + 'Custom');

    return this.formats[type][id];
  },

  listFormats: function(type)
  {
    return this.formats[type];
  },

  strtotime: function(str, year)
  {
    // see if Date() will take this date string
    var d = new Date(str);
    if (d != 'Invalid Date')
      return d;
    else // try to parse a topic date
    {
      year = year || new Date().getFullYear();
      var time = str.split(/(\/| |:|AM|PM)/);
      // Convert to 24-hour scale
      if (time[7] == 'PM' && time[4] < 12)
        time[4] = parseInt(time[4]) + 12;
      if (time[7] == 'AM' && time[4] == 12)
        time[4] = 0;

      return new Date(year, time[0] - 1, time[2], time[4], time[6]);
    }
  },

  convertTo12H: function(hours)
  {
    return hours > 12 ? hours - 12 : (hours == 0 ? 12 : hours);
  },

  parseFormat: function(dateStr, format)
  {
    var date = dateStr ? new Date(dateStr) : new Date();
    if (date == 'Invalid Date')
      date = gamefox_date.strtotime(dateStr);

    // Custom conversions, since strftime isn't adequate
    format = format.replace(/%e/g, date.getDate())
                   .replace(/%n/g, date.getMonth() + 1)
                   .replace(/%i/g, this.convertTo12H(date.getHours()));

    return date.strftime(format);
  }
};
