/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2010 Jesse Lentz
 *
 * This file is part of GameChrome.
 *
 * GameChrome is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameChrome is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameChrome.  If not, see <http://www.gnu.org/licenses/>.
 */

function default_prefs()
{
	window.prefs = {
		'elements.quickpost.form': true,
		'elements.quickpost.button': true,
		'elements.quickpost.htmlbuttons': true,
		'elements.quickpost.htmlbuttons.extended': false,
		'elements.quickpost.htmlbuttons.gfcode': false,
		'elements.quickpost.htmlbuttons.breaktags': true,
		'elements.quickpost.otherbuttons': true,
		'elements.quickpost.link': true,
		'elements.quickpost.link.title': 'QuickPost',
		'elements.quickpost.aftertopic': 0,
		'elements.quickpost.aftermessage': 0,
		'elements.quickpost.resetconfirm': true,
		'elements.quickpost.resetnewsig': false,
		'elements.quickpost.blankPostWarning': true,
		'elements.titlechange': true,
		'elements.titleprefix': false,
		'elements.msgnum': true,
		'elements.msgnum.style': 0,
		'elements.tracked.boardlink': true,
		'elements.charcounts': true,
		'elements.charmap': true,
		'elements.topics.lastpostlink': 1,
		'elements.marktc': true,
		'elements.marktc.marker': '(tc)',
		'elements.favorites': true,
		'elements.clock': true,
		'elements.marknewposts': true,
		'elements.aml.marknewposts': true,
		'elements.aml.pagejumper': true,
		'elements.deletelink': true,
		'elements.filterlink': true,
		'elements.quotelink': true,
		'elements.boardnav': true,
		'elements.statusspans': true,
		'elements.sigspans': true,
		'elements.postidQuoteLinks': true,

		'elements.tti': false,
		'elements.tti.x': '200',
		'elements.tti.y': '200',
		'elements.tti.hoverx': '350',
		'elements.tti.hovery': '350',
		'elements.tti.nosigs': false,

		'msgsPerPage': 50,

		'quote.header.italic': false,
		'quote.header.bold': true,
		'quote.header.date': false,
		'quote.header.username': true,
		'quote.header.messagenum': true,
		'quote.message.italic': true,
		'quote.message.bold': false,
		'quote.removesignature': true,
		'quote.style': 0,
		'quote.controlwhitespace': true,
		'quote.focusQuickPost':  true,

		'sigs': [{'accounts':'', 'boards':'', 'body':''}],
		'signature.newline': false,
		'signature.applyeverywhere': true,
		'signature.addition': 2,
		'signature.selectMostSpecific': true,

		'theme.disablegamefaqscss': false,
		'styles': [
			'gamefox-character-map.css',
			'gamefox-essentials.css',
			'gfcode.css',
			'gamefox-quickpost.css',
			'gamefox-quickwhois.css',
			'gamefox-ads.css'
		],
		'usercss': [],

		'userlist.topics.showgroupnames': false,
		'userlist.messages.showgroupnames': true,
		'userlists': [],

		'favorites': {},
		'favorites.enabled': true,

		'tracked': {},
		'tracked.rssUrl': {},
		'tracked.enabled': true,

		'tracked.lastUpdate': 0,
		'tracked.updateInterval': 300,
		'tracked.notify': true,

		'accounts': [],
		'accounts.current': '',

		'lastVisit': 0,
		'date.enableFormat': false,
		'date.topicPreset': 0,
		'date.topicCustom': '',
		'date.messagePreset': 0,
		'date.messageCustom': '',
		'date.clockPreset': 0,
		'date.clockCustom': '',

		'topic.dblclick': 0,
		'message.dblclick': false,
		'message.header.dblclick': 0,
		'myposts.dblclick': 0,
		'paging.auto': true,
		'paging.location': 2,
		'paging.prefix': '[Pages: ',
		'paging.separator': ', ',
		'paging.suffix': ']',

		'toolbar.userlinks': true,
		'toolbar.favorites': true,
		'toolbar.search': true,
		'toolbar.gotoboard': true,
		'toolbar.login': true,
		'toolbar.accounts': true,
		'toolbar.tracked': true,
		'toolbar.tracked.current': false,
		'toolbar.tti': true,
		'toolbar.classic': false,

		'context.breaktags': true,
		'context.delete': true,
		'context.filter': true,
		'context.pagelist': true,
		'context.quote': true,
		'context.track': true,
		'context.usergroups': true,

		'version': '0.6.1'
	};

	setpref();
}

function setpref(pref, value)
{
	if (pref) prefs[pref] = value;
	localStorage['prefs'] = JSON.stringify(prefs);
}

if (localStorage['prefs'])
	prefs = JSON.parse(localStorage['prefs']);
else
	default_prefs();

function update_prefs(ver)
{
	var cur = prefs.version.split('.');
	var cmp = ver.split('.');

	for (var i = 0; i < Math.max(cur.length, cmp.length); i ++)
	{
		if (cur[i] == undefined)
			return true;
		else if (cmp[i] == undefined)
			return false;
		else if (cur[i] < cmp[i])
			return true;
		else if (cur[i] > cmp[i])
			return false;
	}
	return false;
}

if (update_prefs('0.2'))
{
	prefs['toolbar.tracked.current'] = false;

	var style_list = [];

	for (var cat in prefs.styles)
		for (var i in prefs.styles[cat])
			style_list.push(prefs.styles[cat][i]);

	prefs.styles = style_list;

	for (var i in prefs.userlists)
		for (var item in prefs.userlists[i])
		{
			if (item.search(/(type|topics|messages)/) == -1)
				continue;

			switch (prefs.userlists[i][item])
			{
				case 'users':
					prefs.userlists[i][item] = 0;
					break;
				case 'titleContains':
					prefs.userlists[i][item] = 1;
					break;
				case 'postContains':
					prefs.userlists[i][item] = 2;
					break;
				case 'highlight':
					prefs.userlists[i][item] = 0;
					break;
				case 'remove':
					prefs.userlists[i][item] = 1;
					break;
				case 'nothing':
					prefs.userlists[i][item] = (item == 'topics' ? 2 : 3);
					break;
				case 'collapse':
					prefs.userlists[i][item] = 2;
					break;
			}
		}

	prefs.tracked = {};
	prefs['tracked.rssUrl'] = {};
	delete prefs['tracked.lastAccount'];
}

if (update_prefs('0.3'))
{
	delete prefs['options.main.selectedtab'];
	delete prefs['options.signatures.selectedtab'];
	delete prefs['options.mouse.selectedtab'];
	delete prefs['options.topics.selectedtab'];

	if (typeof prefs['paging.location'] != 'number')
		prefs['paging.location'] = 2;
}

if (update_prefs('0.3.5'))
{
	for (var i in prefs.userlists)
	{
		if (typeof prefs.userlists[i].topics != 'number')
			prefs.userlists[i].topics = parseInt(prefs.userlists[i].topics);

		if (typeof prefs.userlists[i].messages != 'number')
			prefs.userlists[i].messages = parseInt(prefs.userlists[i].messages);
	}

	prefs['elements.tti'] = false;
}

if (update_prefs('0.3.6'))
{
	prefs['elements.tti.x'] = '200';
	prefs['elements.tti.y'] = '200';
	prefs['elements.tti.hoverx'] = '350';
	prefs['elements.tti.hovery'] = '350';
}

if (update_prefs('0.4'))
	prefs.usercss = [];

if (update_prefs('0.4.2'))
	prefs['toolbar.tti'] = true;

if (update_prefs('0.4.3'))
	delete prefs['dateOffset'];

if (update_prefs('0.4.5'))
	prefs['elements.marknewposts'] = true;

if (update_prefs('0.4.6'))
{
	prefs['elements.topics.lastpostlink'] = prefs['elements.topics.lastpostlink'] ? 1 : 0;
	prefs['elements.tti.nosigs'] = false;
}

if (update_prefs('0.5'))
{
	prefs['context.breaktags'] = true;
	prefs['context.delete'] = true;
	prefs['context.filter'] = true;
	prefs['context.pagelist'] = true;
	prefs['context.quote'] = true;
	prefs['context.track'] = true;
	prefs['context.usergroups'] = true;
}

if (update_prefs('0.6'))
{
	delete prefs['tpcsPerPage'];
	delete prefs['msgSortOrder'];
	delete prefs['tpcSortOrder'];
	delete prefs['msgDisplay'];
	delete prefs['timeZone'];
	delete prefs['catShow'];

	prefs['quote.focusQuickPost'] = true;
	prefs['tracked.lastUpdate'] = 0;
	prefs['tracked.updateInterval'] = 300;
	prefs['tracked.notify'] = true;
	prefs['lastVisit'] = 0;

	for (var i = 0; i < prefs.userlists.length; i ++)
	{
		prefs.userlists[i].include = [];
		var list = prefs.userlists[i].users.split(/\s,\s/);
		for (var j = 0; j < list.length; j ++)
			if (list[j] == '(tc)')
			{
				list.splice(j, 1);
				prefs.userlists[i].users = list.join(',');
				prefs.userlists[i].include.push('tc');
				break;
			}
	}

  if (prefs.styles.indexOf('8for11.css') != -1)
    prefs.styles[prefs.styles.indexOf('8for11.css')] = 'retroclassic.css';

  prefs.tracked = {};
}

if (update_prefs('0.6.1'))
  setpref('version', '0.6.1');

chrome.extension.onConnect.addListener(function(port) {
	port.postMessage(prefs);
	port.onMessage.addListener(function(port) {
    return function(msg) {
      if (msg.set)
        setpref(msg.set[0], msg.set[1]);
      else if (msg.context)
        gen_context(port, msg);
      else if (msg.tab)
        chrome.tabs.create({url: msg.tab[0], selected: msg.tab[1]});
      else if (msg == 'track')
        gamefox_tracked.updateList();
    };
  }(port));
});

// disable or update tracked topics
if (!prefs['tracked.enabled'])
{
  prefs['tracked.rssUrl'] = {};
  setpref('tracked', {});
}
else if (prefs['accounts.current'])
{
  gamefox_tracked.updateList();

  if (prefs['tracked.updateInterval'])
    setInterval(gamefox_tracked.updateList, prefs['tracked.updateInterval'] * 1000);
}

// disable favorites
if (!prefs['favorites.enabled'])
  setpref('favorites', {});

function gen_context(port, request)
{
	chrome.contextMenus.removeAll(function() {
		if (prefs['context.breaktags'])
			chrome.contextMenus.create({
				title: 'Break HTML',
				contexts: ['editable'],
				documentUrlPatterns: ['http://www.gamefaqs.com/boards/post.php*', 'http://www.gamefaqs.com/boards/*-*'],
				onclick: function(port) {
					return function() {
						port.postMessage('breaktags');
					};
				}(port)
			});

		if (typeof request != 'object')
			return;

		if (request.context.indexOf('topic') != -1)
		{
			if (prefs['context.track'])
				chrome.contextMenus.create({
					title: (request.tid[1] in prefs.tracked)
						? 'Stop Tracking' : 'Track Topic',
					contexts: ['page', 'link'],
					documentUrlPatterns: [port.sender.tab.url],
					onclick: function(port) {
						return function() {
							port.postMessage('track');
						};
					}(port)
				});

			if (prefs['context.pagelist'] && request.pages > 1)
			{
				var pagemenu = chrome.contextMenus.create({
					title: 'Topic Pages',
					contexts: ['page', 'link'],
					documentUrlPatterns: [port.sender.tab.url]
				});

				for (var i = 1; i <= request.pages; i ++)
					chrome.contextMenus.create({
						title: i + ((request.page && i == request.page) ? '*' : ''),
						contexts: ['page', 'link'],
						onclick: function(port, i) {
							return function() {
								port.postMessage(i - 1);
							};
						}(port, i),
						parentId: pagemenu
					});
			}
		}

		if (request.context.indexOf('msg') != -1)
		{
			if (prefs['context.quote'])
				chrome.contextMenus.create({
					title: 'Quote Message',
					contexts: ['page', 'link'],
					documentUrlPatterns: [port.sender.tab.url],
					onclick: function(port) {
						return function() {
							port.postMessage('quote');
						};
					}(port)
				});

			if (prefs['context.filter'])
				chrome.contextMenus.create({
					title: 'Filter By User',
					contexts: ['page', 'link'],
					documentUrlPatterns: [port.sender.tab.url],
					onclick: function(port) {
						return function() {
							port.postMessage('filter');
						};
					}(port)
				});

			if (prefs['context.delete'] && request.del && request.del != 'none')
				chrome.contextMenus.create({
					title: (request.del == 'deletepost' ? 'Delete Post' : (request.del == 'deletetopic' ? 'Delete Topic' : 'Close Topic')),
					contexts: ['page', 'link'],
					documentUrlPatterns: [port.sender.tab.url],
					onclick: function(port) {
						return function() {
							port.postMessage('del');
						};
					}(port)
				});
		}

		if (prefs['context.usergroups'] && prefs.userlists.length > 0 && request.context.indexOf('groups') != -1)
		{
			var groupmenu = chrome.contextMenus.create({
				title: 'Highlighting Groups',
				contexts: ['page', 'link'],
				documentUrlPatterns: [port.sender.tab.url]
			});

			for (var i = 0; i < prefs.userlists.length; i ++)
			{
				if (prefs.userlists[i].type != 0)
					continue;

				var group = prefs.userlists[i].users.trim().split(/\s*,\s*/);
				if (group[0].length == 0)
					group.splice(0, 1);

				var j = group.indexOf(request.name);
				chrome.contextMenus.create({
					type: 'checkbox',
					title: prefs.userlists[i].name || 'Group ' + (i + 1),
					checked: (j != -1),
					contexts: ['page', 'link'],
					onclick: function(port, i, j, group, name) {
						return function() {
							if (j != -1)
								group.splice(j, 1);
							else
								group.push(name);

							prefs.userlists[i].users = group.join(',');
              chrome.tabs.sendRequest(port.sender.tab.id, 'reload');
						};
					}(port, i, j, group, request.name),
					parentId: groupmenu
				});
			}
		}
	});
}

gen_context();
