/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2008, 2009, 2010 Brian Marshall, Michael Ryan, Andrianto Effendy
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var gamefox_lib =
{
  domain: 'http://www.gamefaqs.com',
  path: '/boards/',

  getPref: function(pref)
  {
    return prefs[pref];
  },

  setPref: function(pref, value)
  {
    chrome.extension.sendRequest([pref, value]);
  },

  onPage: function(page)
  {
    if (document.gamefox.pageType)
      return document.gamefox.pageType.indexOf(page) != -1;

    // pageType is an array because of overlapping pages, e.g. message detail and messages
    switch (page)
    {
      case 'index':
        var div = document.getElementById('side_col');
        if (div)
        {
          var bi = document.evaluate('./div[@class="pod"]/div[@class="head"]/h2', div,
              null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (bi && bi.textContent == 'Board Information')
          {
            document.gamefox.pageType = ['index'];
            return true;
          }
        }
        return false;

      case 'topics':
        var div = document.getElementById('board_wrap');
        if (div)
        {
          if (gamefox_lib.onPage('tracked'))
          {
            document.gamefox.pageType = ['topics', 'tracked'];
            return true;
          }
          var col = document.evaluate('./div[@class="body"]/table[@class="board topics"]/colgroup/col[@class="status"]',
              div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (col)
          {
            document.gamefox.pageType = ['topics'];
            return true;
          }
          // TODO: iterate over all <p> nodes (fails case when deleting only topic on board)
          var notopics = document.evaluate('./p', div, null,
              XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (notopics && notopics.textContent.indexOf('No topics are available') != -1)
          {
            document.gamefox.pageType = ['topics'];
            return true;
          }
        }
        return false;

      case 'messages':
        var div = document.getElementById('board_wrap');
        if (div)
        {
          var table = document.evaluate('//div[@class="body"]/' +
              'table[@class="board message"]', div, null,
              XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (table && !gamefox_lib.onPage('usernote'))
          {
            var boards = document.evaluate('./div[@class="body"]', div, null,
                XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            if (boards.snapshotLength > 1)
              document.gamefox.pageType = ['messages', 'detail'];
            else
            {
              // TODO: maybe check for user profile links instead
              var userPanel = document.evaluate('//div[@class="user_panel"]'
                  + '/div[@class="u_search"]/div[@class="links"]',
                  document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null)
                .singleNodeValue;
              var userNav = document.evaluate('./div[@class="board_nav"]'
                  + '/div[@class="body"]/div[@class="user"]',
                  div, null, XPathResult.FIRST_ORDERED_NODE_TYPE,
                  null).singleNodeValue;
              var user = userPanel || userNav;

              if (user && user.textContent.indexOf(userPanel ?
                    'Topic archived' : 'Topic Archived') != -1)
                document.gamefox.pageType = ['messages', 'archive'];
              else
                document.gamefox.pageType = ['messages'];
            }
            return true;
          }
        }
        return false;

      case 'boardlist':
        var div = document.getElementById('board_wrap');
        if (div)
        {
          var table = document.evaluate('./div[@class="body"]/table[@class="board"]',
              div, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
          if (table && !gamefox_lib.onPage('index'))
          {
            document.gamefox.pageType = ['boardlist'];
            return true;
          }
        }
        return false;

      default:
        return document.location.pathname.indexOf('/boards/' + page + '.php') == 0;
    }
  },

  setTitle: function(title, prefix, page)
  {
    if (!prefs['elements.titlechange']) return;
    if (!prefs['elements.titleprefix']) prefix = null;

    document.title = 'GameFAQs'
      + (prefix == null ? '' : ':' + prefix)
      + (page == null ? '' : ':' + page)
      + ': ' + title;
  }
};
