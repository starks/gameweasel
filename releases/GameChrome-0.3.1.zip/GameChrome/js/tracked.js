/* vim: set et sw=2 ts=2 sts=2 tw=79:
 *
 * Copyright 2009, 2010 Brian Marshall, Michael Ryan
 *
 * This file is part of GameFOX.
 *
 * GameFOX is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation.
 *
 * GameFOX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GameFOX.  If not, see <http://www.gnu.org/licenses/>.
 */

var gamefox_tracked =
{
  updateList: function(callback)
  {
    var account = prefs['accounts.current'];
    if (!prefs['tracked.rssUrl'][account])
    { // No cached url
      var request = new XMLHttpRequest();
      request.open('GET', 'http://www.gamefaqs.com/boards/tracked.php');
      request.onreadystatechange = function()
      {
        if (request.readyState == 4)
        {
          var url = /<link rel="alternate"[^>]*href="(http:\/\/www\.gamefaqs\.com\/boards\/tracked\.xml\?user=\d+&key=[^"]+)" \/>/
            .exec(request.responseText);
          if (url)
          {
            url = url[1];

            prefs['tracked.rssUrl'][account] = url;
            gamefox_tracked.grabFromRSS(url, callback);
          }
        }
      }
      request.send(null);
    }
    else
    {
      // use cached url
      gamefox_tracked.grabFromRSS(prefs['tracked.rssUrl'][account], callback);
    }
  },

  grabFromRSS: function(url, callback)
  {
    var request = new XMLHttpRequest();
    request.open('GET', url);
    request.onreadystatechange = function()
    {
      if (request.readyState == 4)
      {
        var year = new Date().getFullYear();
        var prevLastPost = 0;

        var xmlobject = (new DOMParser()).parseFromString(request.
            responseText.substr(request.responseText.indexOf('>') + 1), 'text/xml');

        var items = xmlobject.getElementsByTagName('item');
        var updated = [];
        for (var i = 0; i < items.length; i++)
        {
          var ids = gamefox_utils.parseBoardLink(items[i].
              getElementsByTagName('link')[0].textContent);
          var bid = ids.board;
          var tid = ids.topic;
          var title = items[i].getElementsByTagName('title')[0].textContent;

          var topic = {
            title: title.substr(0, title.lastIndexOf('-') - 2),
            age: title.substr(title.lastIndexOf('-') + 2),
            accounts: [prefs['accounts.current']],
            newPosts: false
          };
          var data = new Array(
              'Last Post', 'lastPost',
              'Messages', 'msgs',
              'Board', 'board'
              );
          var desc = items[i].getElementsByTagName('description')[0].
            textContent;
          for (var j = 0; j < data.length; j += 2)
          {
            topic[data[j + 1]] = gamefox_utils.trim(
                (new RegExp(data[j] + ': ([^\\0]*?)\n')).
                exec(desc)[1].replace(/<br \/>/g, ''));
          }

          // check for year change
          if (prevLastPost != 0 &&
              prevLastPost < gamefox_date.strtotime(topic.lastPost).getTime())
          {
            // this entry is more recent than the last entry, which should
            // only happen when the year is different
            --year;
          }
          prevLastPost = gamefox_date.strtotime(topic.lastPost).getTime();
          topic.lastPostYear = year;

          if (!prefs.tracked[bid])
            prefs.tracked[bid] = {name: topic.board, topics: {}};

          // check for new posts
          if (prefs.tracked[bid].topics[tid])
          {
            if (topic.lastPost != prefs.tracked[bid].topics[tid].lastPost)
              topic.newPosts = true;

            for (var acc in prefs.tracked[bid].topics[tid].accounts)
              if (prefs.tracked[bid].topics[tid].accounts[acc] != topic.accounts[0])
                topic.accounts.push(prefs.tracked[bid].topics[tid].accounts[acc]);
          }

          prefs.tracked[bid].topics[tid] = topic;
          updated.push(tid);
        }

        // check deleted topics
        for (var i in prefs.tracked)
        {
          for (var j in prefs.tracked[i].topics)
            if (in_array(prefs['accounts.current'], prefs.tracked[i].topics[j].accounts) && !in_array(j, updated))
              delete prefs.tracked[i].topics[j];

          // TODO : FIX THIS
          if (prefs.tracked[i].topics.__count__ == 0)
            delete prefs.tracked[i];
        }

	      setpref();
        if (callback)
          callback();
      }
    }
    request.send(null);
  },

  deleteTopic: function(boardId, topicId)
  {
    var topic = bg.prefs.tracked[boardId].topics[topicId];
    if (!topic.deleted)
    {
      var request = new XMLHttpRequest();
      request.open('GET', gamefox_utils.linkToTopic(boardId, topicId) + '?action=stoptrack');
      request.onreadystatechange = function()
      {
        if (request.readyState == 4)
        {
          if (request.responseText.indexOf('no longer tracking') != -1)
            gamefox_tracked.updateList();
          else
            alert('An error occurred untracking this topic.');
        }
      }
      request.send(null);
    }
    else
    {
      delete bg.prefs.tracked[boardId].topics[topicId];

      if (!bg.prefs.tracked[boardId].topics.__count__)
        delete bg.prefs.tracked[boardId]; // board is empty

      bg.setpref();
    }
  }
};

function in_array(item, arr)
{
  for (var i in arr)
    if (arr[i] == item)
      return true;

  return false;
}
